# -*- coding: utf-8 -*-
from . import applicant_model