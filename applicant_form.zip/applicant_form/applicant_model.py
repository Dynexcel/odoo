from openerp import models, fields, api, exceptions, _


class employee_form(models.Model):
    _inherit = 'hr.applicant'

    x_spouse_name = fields.Char('Spouse Name')
    x_father_name = fields.Char('Father Name')
    x_date_o_b = fields.Date(default=fields.Date.today)
    x_gender = fields.Selection(selection=[('male', 'Male'),('female', 'Female')],string='Gender')
    x_marital_status = fields.Selection(selection=[('single', 'Single'),('married', 'Married'),('widower', 'Widower'),('divorced', 'Divorced')],string='Marital Status')
    x_language = fields.Selection(selection=[('english', 'English'),('urdu', 'Urdu'),('punjabi', 'Punjabi'),('pashto', 'Pashto')],string='Language')

    x_experience_in_year = fields.Char('Experience',size=4)
    x_designation = fields.Char('Designation')
    x_organization = fields.Char('Organization')
    x_total_experience = fields.Char('Total Experience(s)',size=4)


class partner_form(models.Model):
    _inherit = 'res.partner'

    x_district = fields.Char('District/Agency')
    x_tehsil = fields.Char('Tehsil')
    x_uc = fields.Char('UC')
    x_area = fields.Char('Area')
    x_sub_area = fields.Char('Sub Area')


class partner_form1(models.Model):
    _inherit = 'hr.employee'

    x_working_address = fields.Many2one('res.partner', string="Working Address2")
    x_postal_address = fields.Many2one('res.partner', string="Postal Address")

    def onchange_x_address_id(self, cr, uid, ids, address, context=None):
        if address:
            address = self.pool.get('res.partner').browse(cr, uid, address, context=context)
            return {'value': {'work_phone': address.phone, 'mobile_phone': address.mobile}}
        return {'value': {}}